// 한 프로세스에서 Node 기본 테스트 러너 사용. 추가 패키지가 없습니다.
import './core.test.js';
import './analytics.test.js';
